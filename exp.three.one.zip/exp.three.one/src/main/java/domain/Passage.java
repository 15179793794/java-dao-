package domain;

public class Passage {

}
