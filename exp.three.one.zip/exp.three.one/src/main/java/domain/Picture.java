package domain;

public class Picture {
    private String sort;
    private String author;
    private String url;
}
