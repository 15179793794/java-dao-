package DAO;

import domain.User;
import junit.framework.TestCase;
import servlet.main.VerifyCode;

import java.sql.SQLException;

public class MyDAOSelectTest extends TestCase {

    public void testSelectIsExistUser() throws SQLException {
        MyDAO myDAO = new MyDAO();
        Boolean flag = myDAO.verifyUser("wry01","123546");
        if (!flag) {
            System.out.println("user isn't null");
        } else {
            System.out.println("null");
        }
    }

}