package DAO;

import common.JdbcUtils;
import domain.User;
import junit.framework.TestCase;
import org.junit.Test;

import java.sql.SQLException;

//    public void testGetConn() throws SQLException {
//        if (JdbcUtils.getConn()!=null) {
//            System.out.println("yes");
//        }
//    }
class myDAOTest{


public void testInsertUser() throws SQLException {
          MyDAO myDAO = new MyDAO();
          myDAO.insertUser("ssss","asas");
      }
}