package DAO;


import org.junit.Test;

public class Test43434 {
    @Test
    public void testInsert() {
        System.out.println("as");
    }
}
